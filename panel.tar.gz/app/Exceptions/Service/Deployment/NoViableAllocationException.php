<?php

namespace Pterodactyl\Exceptions\Service\Deployment;

use Pterodactyl\Exceptions\DisplayException;

class NoViableAllocationException extends DisplayException
{
}
